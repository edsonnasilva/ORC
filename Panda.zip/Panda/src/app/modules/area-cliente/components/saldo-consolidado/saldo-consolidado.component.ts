import { Component, OnInit } from "@angular/core";
import { SaldoConsolidadoInterface } from "./Interfaces/SaldoConsolidadeInterface";

import { SALDOS_CONSOLIDADOS } from "./data/SaldosConsolidadosData";

@Component({
  selector: "pd-saldo-consolidado",
  templateUrl: "./saldo-consolidado.component.html",
  styleUrls: ["./saldo-consolidado.component.scss"]
})
export class SaldoConsolidadoComponent implements OnInit {
  dataSource: SaldoConsolidadoInterface[] = SALDOS_CONSOLIDADOS;
  headerColumns: string[] = [
    "classe",
    "saldo bruto(MM)",
    "% atual",
    "% tática",
    "% gap"
  ];

  constructor() {}

  ngOnInit() {}
}
