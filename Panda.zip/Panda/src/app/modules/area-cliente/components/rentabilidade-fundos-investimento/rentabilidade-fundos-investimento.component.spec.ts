import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentabilidadeFundosInvestimentoComponent } from './rentabilidade-fundos-investimento.component';

describe('RentabilidadeFundosInvestimentoComponent', () => {
  let component: RentabilidadeFundosInvestimentoComponent;
  let fixture: ComponentFixture<RentabilidadeFundosInvestimentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentabilidadeFundosInvestimentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentabilidadeFundosInvestimentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
