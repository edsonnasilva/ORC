import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipeAtendeComponent } from './equipe-atende.component';

describe('EquipeAtendeComponent', () => {
  let component: EquipeAtendeComponent;
  let fixture: ComponentFixture<EquipeAtendeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EquipeAtendeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipeAtendeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
