import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-estatisticas',
  templateUrl: './estatisticas.component.html',
  styleUrls: ['./estatisticas.component.scss']
})
export class EstatisticasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
