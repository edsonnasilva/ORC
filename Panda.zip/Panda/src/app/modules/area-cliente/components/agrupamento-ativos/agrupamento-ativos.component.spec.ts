import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgrupamentoAtivosComponent } from './agrupamento-ativos.component';

describe('AgrupamentoAtivosComponent', () => {
  let component: AgrupamentoAtivosComponent;
  let fixture: ComponentFixture<AgrupamentoAtivosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgrupamentoAtivosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgrupamentoAtivosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
