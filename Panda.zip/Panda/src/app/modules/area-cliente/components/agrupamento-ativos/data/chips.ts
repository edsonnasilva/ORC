export var CHIPS_ELEMENTS = [
    {
        id: 1,
        label: "instituição"
    },
    {
        id: 2,
        label: "classes"
    },
    {
        id: 3,
        label: "ativos"
    }
]