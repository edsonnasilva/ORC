import { Component, OnInit } from "@angular/core";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";

/* Interface */
import { ChipsAtivosInterface } from "./interfaces/ChipsAtivosInterface";

/* Datas */
import { CHIPS_ELEMENTS } from "./data/chips";

@Component({
  selector: "pd-agrupamento-ativos",
  templateUrl: "./agrupamento-ativos.component.html",
  styleUrls: ["./agrupamento-ativos.component.scss"]
})
export class AgrupamentoAtivosComponent implements OnInit {
  // timePeriods: ChipsAtivosInterface[] = [
  //   'instituição',
  //   'classes',
  //   'ativos',
  // ];

  chipsAtivos: ChipsAtivosInterface[] = CHIPS_ELEMENTS;

  constructor() {}

  ngOnInit() {}

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.chipsAtivos, event.previousIndex, event.currentIndex);
  }
}
