import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvolucaoAlocacaoComponent } from './evolucao-alocacao.component';

describe('EvolucaoAlocacaoComponent', () => {
  let component: EvolucaoAlocacaoComponent;
  let fixture: ComponentFixture<EvolucaoAlocacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvolucaoAlocacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvolucaoAlocacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
