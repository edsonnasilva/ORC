import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-evolucao-alocacao',
  templateUrl: './evolucao-alocacao.component.html',
  styleUrls: ['./evolucao-alocacao.component.scss']
})
export class EvolucaoAlocacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
