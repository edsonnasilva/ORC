import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContatoPreferencialComponent } from './contato-preferencial.component';

describe('ContatoPreferencialComponent', () => {
  let component: ContatoPreferencialComponent;
  let fixture: ComponentFixture<ContatoPreferencialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContatoPreferencialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContatoPreferencialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
