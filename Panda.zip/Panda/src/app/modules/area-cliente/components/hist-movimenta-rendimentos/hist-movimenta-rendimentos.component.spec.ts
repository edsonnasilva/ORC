import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistMovimentaRendimentosComponent } from './hist-movimenta-rendimentos.component';

describe('HistMovimentaRendimentosComponent', () => {
  let component: HistMovimentaRendimentosComponent;
  let fixture: ComponentFixture<HistMovimentaRendimentosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistMovimentaRendimentosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistMovimentaRendimentosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
