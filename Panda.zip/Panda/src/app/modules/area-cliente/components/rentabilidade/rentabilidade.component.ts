import { Component, OnInit } from '@angular/core';
import { RENTABILIDADE_ELEMENT } from './data/Rentabilidade';

@Component({
  selector: 'pd-rentabilidade',
  templateUrl: './rentabilidade.component.html',
  styleUrls: ['./rentabilidade.component.scss']
})
export class RentabilidadeComponent {
  multi: any[];
  view: any[] = [400, 300];

  // options
  legend: boolean = true;
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  xAxisLabel: string = 'Year';
  yAxisLabel: string = 'Population';
  timeline: boolean = true;

  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };

  constructor() {
    Object.assign(this, { RENTABILIDADE_ELEMENT });
  }

  onSelect(event) {
    console.log(event);
  }
  

}
