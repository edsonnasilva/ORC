import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { AreaClienteRoutingModule } from "./app-routing.module";
import { GridstackModule } from "@libria/gridstack";

import { AreaClienteComponent } from "./pages/area-cliente/area-cliente.component";
import { SaldoConsolidadoComponent } from "./components/saldo-consolidado/saldo-consolidado.component";
import { RentabilidadeComponent } from "./components/rentabilidade/rentabilidade.component";
import { AtividadesComponent } from "./components/atividades/atividades.component";

import { TabsModule } from "ngx-bootstrap/tabs";
import { TabDashboardComponent } from "./pages/tab-dashboard/tab-dashboard.component";
import { TabRentabilidadeComponent } from "./pages/tab-rentabilidade/tab-rentabilidade.component";
import { TabAtivosComponent } from "./pages/tab-ativos/tab-ativos.component";
import { TabAlocacaoComponent } from "./pages/tab-alocacao/tab-alocacao.component";

import { ContatoPreferencialComponent } from "./components/contato-preferencial/contato-preferencial.component";
import { ResumoFinanceiroComponent } from "./components/resumo-financeiro/resumo-financeiro.component";
import { SaldoGlobalComponent } from "./components/saldo-global/saldo-global.component";
import { EquipeAtendeComponent } from "./components/equipe-atende/equipe-atende.component";
import { LiquidezComponent } from "./components/liquidez/liquidez.component";
import { DesempenhoComparativoComponent } from "./components/desempenho-comparativo/desempenho-comparativo.component";
import { RentabilidadeClasseAtivoComponent } from "./components/rentabilidade-classe-ativo/rentabilidade-classe-ativo.component";
import { ContribuicaoRentabilidadeComponent } from "./components/contribuicao-rentabilidade/contribuicao-rentabilidade.component";
import { HistMovimentaRendimentosComponent } from "./components/hist-movimenta-rendimentos/hist-movimenta-rendimentos.component";
import { DrawdownComponent } from "./components/drawdown/drawdown.component";
import { EstatisticasComponent } from "./components/estatisticas/estatisticas.component";
import { RentabilidadeFundosInvestimentoComponent } from "./components/rentabilidade-fundos-investimento/rentabilidade-fundos-investimento.component";
import { AgrupamentoAtivosComponent } from "./components/agrupamento-ativos/agrupamento-ativos.component";
import { EvolucaoAlocacaoComponent } from "./components/evolucao-alocacao/evolucao-alocacao.component";

@NgModule({
  declarations: [
    AreaClienteComponent,
    SaldoConsolidadoComponent,
    RentabilidadeComponent,
    AtividadesComponent,
    TabDashboardComponent,
    TabRentabilidadeComponent,
    TabAtivosComponent,
    TabAlocacaoComponent,
    ContatoPreferencialComponent,
    ResumoFinanceiroComponent,
    SaldoGlobalComponent,
    EquipeAtendeComponent,
    LiquidezComponent,
    DesempenhoComparativoComponent,
    RentabilidadeClasseAtivoComponent,
    ContribuicaoRentabilidadeComponent,
    HistMovimentaRendimentosComponent,
    DrawdownComponent,
    EstatisticasComponent,
    RentabilidadeFundosInvestimentoComponent,
    AgrupamentoAtivosComponent,
    EvolucaoAlocacaoComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AreaClienteRoutingModule,
    GridstackModule.forRoot(),
    TabsModule.forRoot(),

  ],
  entryComponents: [AtividadesComponent]
})
export class AreaClienteModule {}
