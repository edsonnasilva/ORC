import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LiquidezComponent } from './liquidez.component';

describe('LiquidezComponent', () => {
  let component: LiquidezComponent;
  let fixture: ComponentFixture<LiquidezComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LiquidezComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LiquidezComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
