import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-tab-rentabilidade',
  templateUrl: './tab-rentabilidade.component.html',
  styleUrls: ['./tab-rentabilidade.component.scss']
})
export class TabRentabilidadeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
