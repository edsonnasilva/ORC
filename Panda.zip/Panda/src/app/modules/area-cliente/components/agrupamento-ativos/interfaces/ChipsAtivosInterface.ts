export interface ChipsAtivosInterface{
    id: number,
    label: string
}