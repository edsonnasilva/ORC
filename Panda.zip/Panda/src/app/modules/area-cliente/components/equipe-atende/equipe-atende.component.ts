import { Component, OnInit } from '@angular/core';

/* Interface */
import { EquipeAtendeInterface } from "./Interfaces/EquipeAtendeInterface";

/* Data */
import { EQUIPE_ELEMENT } from "./data/equipe-data";

@Component({
  selector: 'pd-equipe-atende',
  templateUrl: './equipe-atende.component.html',
  styleUrls: ['./equipe-atende.component.scss']
})
export class EquipeAtendeComponent implements OnInit {

  datasource: EquipeAtendeInterface[] = EQUIPE_ELEMENT

  constructor() { }

  ngOnInit() {
  }

}
