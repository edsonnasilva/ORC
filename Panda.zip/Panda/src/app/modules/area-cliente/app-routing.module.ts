import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AreaClienteComponent } from "./pages/area-cliente/area-cliente.component";
import { TabDashboardComponent } from './pages/tab-dashboard/tab-dashboard.component';
import { TabRentabilidadeComponent } from './pages/tab-rentabilidade/tab-rentabilidade.component';
import { TabAtivosComponent } from './pages/tab-ativos/tab-ativos.component';
import { TabAlocacaoComponent } from './pages/tab-alocacao/tab-alocacao.component';

const routes: Routes = [
  { 
    path: 'AreaCliente', 
    component: AreaClienteComponent,
    children: [
      {
        path: "",
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: "dashboard",
        component: TabDashboardComponent
      },
      {
        path: "rentabilidade",
        component: TabRentabilidadeComponent
      },
      {
        path: "ativos",
        component: TabAtivosComponent
      },
      {
        path: "alocacao",
        component: TabAlocacaoComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class AreaClienteRoutingModule {}
