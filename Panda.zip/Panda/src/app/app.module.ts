/* Core's Angular */
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";

/* Module's & Routes App*/
import { HomeModule } from "./modules/home/home.module";
import { AreaClienteModule } from "./modules/area-cliente/area-cliente.module";

/* Module's & libs */
import { GridstackModule } from "@libria/gridstack";
import { MatInputModule } from "@angular/material/input";

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,

    HomeModule,
    AreaClienteModule,

    GridstackModule.forRoot(),

    MatInputModule,

    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  
})
export class AppModule {}
