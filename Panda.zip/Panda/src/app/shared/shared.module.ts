import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SidebarComponent } from "./layout/sidebar/sidebar.component";
import { NavbarComponent } from "./layout/navbar/navbar.component";
import { MaterialModule } from "./material.module";
import { NgxChartsModule } from "@swimlane/ngx-charts";
// import { NgScrollbarModule } from 'ngx-scrollbar';

@NgModule({
  declarations: [SidebarComponent, NavbarComponent],
  exports: [
    SidebarComponent,
    NavbarComponent,
    MaterialModule,
    NgxChartsModule
    // NgScrollbarModule
  ],
  imports: [
    CommonModule,
    MaterialModule,
    NgxChartsModule
    // NgScrollbarModule
  ]
})
export class SharedModule {}
