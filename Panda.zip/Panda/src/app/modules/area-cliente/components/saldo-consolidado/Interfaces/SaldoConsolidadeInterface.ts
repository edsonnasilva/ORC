export interface SaldoConsolidadoInterface {
  id: number;
  classe: string;
  saldoBruto: string;
  porcentagemAtual: string;
  porcentagemTatica: string;
  porcentagemGap: string;
}
