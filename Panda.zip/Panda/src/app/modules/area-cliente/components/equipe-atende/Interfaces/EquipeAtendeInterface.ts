export interface EquipeAtendeInterface {
    id: number,
    nome: string,
    cargo: string
    sourceImage: string
}