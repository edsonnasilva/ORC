import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContribuicaoRentabilidadeComponent } from './contribuicao-rentabilidade.component';

describe('ContribuicaoRentabilidadeComponent', () => {
  let component: ContribuicaoRentabilidadeComponent;
  let fixture: ComponentFixture<ContribuicaoRentabilidadeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContribuicaoRentabilidadeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContribuicaoRentabilidadeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
