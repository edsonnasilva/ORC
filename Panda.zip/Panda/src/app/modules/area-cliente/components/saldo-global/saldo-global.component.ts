import { Component, OnInit } from '@angular/core';

export interface SaldoGlobal {
  id: number;
  stateShore: string;
  brl: string;
  usd: string;
  porcentagem: string;
  
}

const ELEMENT_DATA : SaldoGlobal[] = [
  {
    id: 0,
    stateShore: "onShore",
    brl: "12,2",
    usd: "12.2",
    porcentagem: "100"
  }
]

@Component({
  selector: 'pd-saldo-global',
  templateUrl: './saldo-global.component.html',
  styleUrls: ['./saldo-global.component.scss']
})
export class SaldoGlobalComponent implements OnInit {

  headerColumns: string[] = ['shore', 'BRL', 'USD', '%'];
  dataSource = ELEMENT_DATA;

  constructor() { }

  ngOnInit() {
  }

}
