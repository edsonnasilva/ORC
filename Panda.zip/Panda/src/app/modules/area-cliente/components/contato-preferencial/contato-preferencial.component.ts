import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-contato-preferencial',
  templateUrl: './contato-preferencial.component.html',
  styleUrls: ['./contato-preferencial.component.scss']
})
export class ContatoPreferencialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
