$("#txtFuncionalColaborador, #txtSenha").on("focus", function (e) {
    var divFather = $(e.currentTarget).parents(".input-material-container");
    $(divFather)
        .children("i")
        .removeClass("text-grey");
    $(divFather)
        .children("i")
        .addClass("text-orange");
    $(divFather)
        .children("label")
        .removeClass("text-grey");
    $(divFather)
        .children("label")
        .addClass("text-orange");
});
$("#txtFuncionalColaborador, #txtSenha").on("blur", function (e) {
    var divFather = $(e.currentTarget).parents(".input-material-container");
    $(divFather)
        .children("i")
        .removeClass("text-orange");
    $(divFather)
        .children("label")
        .addClass("text-grey");
    $(divFather)
        .children("label")
        .removeClass("text-orange");
});


const alertError = () => {
    var layoutErrorAlert = `
     <div class="alert alert-red py-3 mt-2" role="alert" id="alertErrorLogin">
         <div class="text-white align-baseline">
         <img src="../Assets/Svgs/icon_erro.svg" class="mx-4">
          
             Erro no login, Usuário não tem permissão.
             Entre em contato com o admistrador. 
             <a href="error.html" class="text-white">(clique para ver o erro)</a>
             <a href="#" id="btnCloseAlertLogin" class="align-baseline icon-itaufonts_fechar float-right text-white text-decoration-none"></a>
         <div>
     </div>`;
    $('#errorHandler').append(layoutErrorAlert);
}
$(document.body).on('click', '#btnCloseAlertLogin', function () {
    $('#alertErrorLogin').remove();
})
alertError()


var ulSquares = document.querySelector("ul.squares");
for (var i = 0; i < 20; i++) {
    var li = document.createElement("li");
    var random = function random(min, max) {
        return Math.random() * (max - min) + min;
    };
    var size = Math.floor(random(10, 120));
    var position = random(1, 99);
    var delay = random(5, 0.1);
    var duration = random(24, 12);
    li.style.width = size + "px";
    li.style.height = size + "px";
    li.style.bottom = "-" + size + "px";
    li.style.left = position + "%";
    li.style.animationDelay = delay + "s";
    li.style.animationDuration = duration + "s";
    li.style.animationTimingFunction =
        "cubic-bezier(" +
        (Math.random() + 50) +
        ", " +
        Math.random() +
        ", " +
        Math.random() +
        ", " +
        Math.random() +
        ")";
    li.classList.add("rounded");
    ulSquares.appendChild(li);
}
