import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-rentabilidade-fundos-investimento',
  templateUrl: './rentabilidade-fundos-investimento.component.html',
  styleUrls: ['./rentabilidade-fundos-investimento.component.scss']
})
export class RentabilidadeFundosInvestimentoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
