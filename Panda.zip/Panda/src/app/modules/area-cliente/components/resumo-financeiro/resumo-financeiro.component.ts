import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-resumo-financeiro',
  templateUrl: './resumo-financeiro.component.html',
  styleUrls: ['./resumo-financeiro.component.scss']
})
export class ResumoFinanceiroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
