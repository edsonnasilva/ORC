import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaldoConsolidadoComponent } from './saldo-consolidado.component';

describe('SaldoConsolidadoComponent', () => {
  let component: SaldoConsolidadoComponent;
  let fixture: ComponentFixture<SaldoConsolidadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaldoConsolidadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaldoConsolidadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
