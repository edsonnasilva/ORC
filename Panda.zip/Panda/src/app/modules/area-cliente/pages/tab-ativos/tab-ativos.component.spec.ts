import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabAtivosComponent } from './tab-ativos.component';

describe('TabAtivosComponent', () => {
  let component: TabAtivosComponent;
  let fixture: ComponentFixture<TabAtivosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabAtivosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabAtivosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
