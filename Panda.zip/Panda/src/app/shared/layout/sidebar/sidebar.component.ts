import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  toggleSidebar(){

    const sidebar = document.querySelector('#sidebar');
    const svgArrow = document.querySelector('#arrowToggleSidebar');
    const navbar = document.querySelector('#navbar');

    document.querySelector("#content-btnSearchPanda").classList.remove("d-none")
    document.querySelector("#content-search").classList.add("d-none")

    if(!sidebar.classList.contains('expanded')){
      sidebar.classList.add('expanded');
      svgArrow.classList.add('active-in-rotate');
      navbar.classList.add('w-90');
    
    }else{
      sidebar.classList.remove('expanded');
      svgArrow.classList.remove('active-in-rotate')
      navbar.classList.remove('w-90');
    }
  }

  openSearchPanda(){
    const sidebar = document.querySelector('#sidebar');

    if(!sidebar.classList.contains('expanded')){
      this.toggleSidebar();
    }

    console.log("oii")
      
    document.querySelector("#content-btnSearchPanda").classList.add("d-none")
    document.querySelector("#content-search").classList.remove("d-none")
  }

}
