import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabRentabilidadeComponent } from './tab-rentabilidade.component';

describe('TabRentabilidadeComponent', () => {
  let component: TabRentabilidadeComponent;
  let fixture: ComponentFixture<TabRentabilidadeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabRentabilidadeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabRentabilidadeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
