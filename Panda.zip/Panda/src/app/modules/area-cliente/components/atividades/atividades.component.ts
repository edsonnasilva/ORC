import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-atividades',
  templateUrl: './atividades.component.html',
  styleUrls: ['./atividades.component.scss']
})
export class AtividadesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
