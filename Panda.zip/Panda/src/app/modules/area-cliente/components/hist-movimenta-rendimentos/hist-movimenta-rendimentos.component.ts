import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-hist-movimenta-rendimentos',
  templateUrl: './hist-movimenta-rendimentos.component.html',
  styleUrls: ['./hist-movimenta-rendimentos.component.scss']
})
export class HistMovimentaRendimentosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
