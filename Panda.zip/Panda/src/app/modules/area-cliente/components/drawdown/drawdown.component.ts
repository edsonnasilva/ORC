import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-drawdown',
  templateUrl: './drawdown.component.html',
  styleUrls: ['./drawdown.component.scss']
})
export class DrawdownComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
