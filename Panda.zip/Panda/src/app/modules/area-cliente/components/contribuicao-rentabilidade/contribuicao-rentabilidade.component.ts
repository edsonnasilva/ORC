import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-contribuicao-rentabilidade',
  templateUrl: './contribuicao-rentabilidade.component.html',
  styleUrls: ['./contribuicao-rentabilidade.component.scss']
})
export class ContribuicaoRentabilidadeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
