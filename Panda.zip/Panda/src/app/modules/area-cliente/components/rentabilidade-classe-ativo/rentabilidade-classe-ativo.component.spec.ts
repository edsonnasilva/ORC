import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentabilidadeClasseAtivoComponent } from './rentabilidade-classe-ativo.component';

describe('RentabilidadeClasseAtivoComponent', () => {
  let component: RentabilidadeClasseAtivoComponent;
  let fixture: ComponentFixture<RentabilidadeClasseAtivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentabilidadeClasseAtivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentabilidadeClasseAtivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
