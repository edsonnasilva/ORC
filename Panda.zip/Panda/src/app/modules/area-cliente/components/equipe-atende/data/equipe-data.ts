export var EQUIPE_ELEMENT = [
    {
        id: 1,
        nome: "Marcos Ramos",
        cargo: "assistente comercial",
        sourceImage: "../../../../../assets/img/avatar-empresa_01.png",
        
    },
    {
        id: 3,
        nome: "Clara Oliveira",
        cargo: "assistente comercial",
        sourceImage: "../../../../../assets/img/avatar-empresa_02.png",
        
    },
    {
        id: 3,
        nome: "Danilo Ferreia",
        cargo: "assistente comercial",
        sourceImage: "../../../../../assets/img/avatar-empresa_03.png",
        
    },
]