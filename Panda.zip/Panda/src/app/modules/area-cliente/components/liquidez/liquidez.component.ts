import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-liquidez',
  templateUrl: './liquidez.component.html',
  styleUrls: ['./liquidez.component.scss']
})
export class LiquidezComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
