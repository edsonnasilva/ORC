import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-rentabilidade-classe-ativo',
  templateUrl: './rentabilidade-classe-ativo.component.html',
  styleUrls: ['./rentabilidade-classe-ativo.component.scss']
})
export class RentabilidadeClasseAtivoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
