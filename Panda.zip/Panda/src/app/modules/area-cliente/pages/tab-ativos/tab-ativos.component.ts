import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-tab-ativos',
  templateUrl: './tab-ativos.component.html',
  styleUrls: ['./tab-ativos.component.scss']
})
export class TabAtivosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
