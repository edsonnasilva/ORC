export var SALDOS_CONSOLIDADOS = [
  {
    id: 0,
    classe: "pós-fixado",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  },
  {
    id: 1,
    classe: "prefixado",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  },
  {
    id: 2,
    classe: "inflação",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  },
  {
    id: 3,
    classe: "multimercado",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  },
  {
    id: 4,
    classe: "renda variável",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  },
  {
    id: 5,
    classe: "alternativos",
    saldoBruto: "0",
    porcentagemAtual: "0",
    porcentagemTatica: "0",
    porcentagemGap: "0"
  }
];
