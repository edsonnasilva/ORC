$(document).ready(function() {
  var $contentWrapper = $(`#content-wrapper`);
  var prevScrollpos = $contentWrapper.scrollTop();

  $contentWrapper.on("scroll", function() {
    var currentScrollPos = $contentWrapper.scrollTop();
    if (prevScrollpos > currentScrollPos) {
      document.getElementById("navbar").style.top = "0";
      document.querySelector("#content").classList.remove("mt-0");
    } else {
      document.getElementById("navbar").style.top = "-100px";
      document.querySelector("#content").classList.add("mt-0");
    }
    prevScrollpos = currentScrollPos;
  });
});
