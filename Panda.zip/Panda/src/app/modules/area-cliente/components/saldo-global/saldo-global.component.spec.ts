import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaldoGlobalComponent } from './saldo-global.component';

describe('SaldoGlobalComponent', () => {
  let component: SaldoGlobalComponent;
  let fixture: ComponentFixture<SaldoGlobalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaldoGlobalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaldoGlobalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
