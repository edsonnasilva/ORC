import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-desempenho-comparativo',
  templateUrl: './desempenho-comparativo.component.html',
  styleUrls: ['./desempenho-comparativo.component.scss']
})
export class DesempenhoComparativoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
