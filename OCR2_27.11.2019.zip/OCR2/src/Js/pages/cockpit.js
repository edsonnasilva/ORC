$(document.body).on("click", ".timeline li", (element) => {
  $(".timeline li").removeClass("active");
  $(element.currentTarget).addClass("active");
});

$(document.body).on("click", "#btnAprovarCockpit", () => {
  var msgHTML = `
  <div class="row">
      <div class="col pt-2 ml-5">
          <img src="img/icon-feliz.png" class="mx-4">
          <label class="text-white">
              licenças efetivadas com sucesso!
          </label>
          <a href="#" class="ml-3 font-weight-bold text-white decore-underline" 
          id="btnDesfazer_aprovarCockpit" role="button">
              Desfazer?
          </a>
      </div>
  </div>`;

  fnAlertaVerde(msgHTML);
});

$(document.body).on("click", "#btnDesfazer_aprovarCockpit", () => {
  $("[name=alertaVerde]").fadeOut((e) => {
    $(e.currentTarget).remove();
  })
});

$(document.body).on('DOMSubtreeModified', "#slcDropdownRecusarCockpit", (elThis) => {
  if ($(elThis.currentTarget)[0].innerText.trim() === 'personalizar'.trim()) {
    $("#divMotivoRecusar").fadeOut((elThis) => {
      $("#divMotivoPersonalizar").removeClass("d-none")
    })
  }
});

$('#txtMotivoPersonalizado').on('keyup', function () {
  $('#countCharPersonalizado').html(this.value.length);
});

function resetModalRecusar() {
  $('#recusarModal').modal("hide");
  $('#divMotivoRecusar').css({ display: '' })
  $('#divMotivoRecusar').removeClass('d-none')
  $('#slcDropdownRecusarCockpit').html('Selecione');
  $('#txtMotivoPersonalizado').val('')
  $('#countCharPersonalizado').html('0')
  $('#divMotivoPersonalizar').addClass('d-none')
}

$(document.body).on('click', '#btnMotivoRecusarCockipt', () => {
  var msgHTML = `
  <div class="row">
      <div class="col pt-2 ml-5">
          <img src="img/icon-feliz.png" class="mx-4">
          <label class="text-white">
              licenças recusadas com sucesso. mensagem enviado para o gestor!
          </label>
          <a href="#" class="ml-3 font-weight-bold text-white decore-underline" 
          id="btnDesfazer_aprovarCockpit" role="button">
              Desfazer?
          </a>
      </div>
  </div>`;

  resetModalRecusar()

  setTimeout(() => {
    fnAlertaVerde(msgHTML);
  }, 250)
})

$(document.body).on('click', '.btnCancelarModalR', () => {
  resetModalRecusar();
})



const fnAlertaVerde = (contentHTML) => {
  var layoutTemplete = `
  <div class="center-page" name="alertaVerde">
      <div class="alert alert-success" role="alert">
          <div class="container px-0 mx-0">
              ${contentHTML}
          </div>
      </div>
  </div>`;

  $(document.body).append(layoutTemplete);
};


