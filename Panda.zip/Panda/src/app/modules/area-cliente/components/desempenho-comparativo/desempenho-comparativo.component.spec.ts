import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesempenhoComparativoComponent } from './desempenho-comparativo.component';

describe('DesempenhoComparativoComponent', () => {
  let component: DesempenhoComparativoComponent;
  let fixture: ComponentFixture<DesempenhoComparativoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesempenhoComparativoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesempenhoComparativoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
