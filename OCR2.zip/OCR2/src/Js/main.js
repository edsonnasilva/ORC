"use strict";

/*
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" data-type="primary" title="Primary">Primary</button>
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" data-type="info" title="Info">Info</button>
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" data-type="success" title="Success">Success</button>
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" data-type="warning" title="Warning">Warning</button>
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" data-type="danger" title="Danger">Danger</button>
*/
$('[data-toggle="tooltip"]').each(function () {
  var options = {
    html: true
  };

  if ($(this)[0].hasAttribute("data-type")) {
    options["template"] =
      '<div class="tooltip ' +
      $(this).attr("data-type") +
      '" role="tooltip">' +
      '	<div class="tooltip-arrow"></div>' +
      '	<div class="tooltip-inner"></div>' +
      "</div>";
  }

  $(this).tooltip(options);
}); // Função conteúdo do botão do dropdown

$(document).on("click", "main .dropdown-item", function (event) {
  event.preventDefault();
  console.log(event);
  $(event.currentTarget).parent().children(".dropdown-item").removeClass("active");
  $(event.currentTarget).addClass("active");
  var muda = $(event.currentTarget).html();
  $(event.currentTarget).parents(".dropdown").find("button span").html(muda)
});


{
  var links = document.querySelectorAll(".ripplelink");

  for (var i = 0, len = links.length; i < len; i++) {
    links[i].addEventListener(
      "click",
      function (e) {
        var targetEl = e.target;
        var inkEl = targetEl.querySelector(".ink");

        if (inkEl) {
          inkEl.classList.remove("animate");
        } else {
          inkEl = document.createElement("span");
          inkEl.classList.add("ink");
          inkEl.style.width = inkEl.style.height =
            Math.max(targetEl.offsetWidth, targetEl.offsetHeight) + "px";
          targetEl.appendChild(inkEl);
        }

        inkEl.style.left = e.offsetX - inkEl.offsetWidth / 2 + "px";
        inkEl.style.top = e.offsetY - inkEl.offsetHeight / 2 + "px";
        inkEl.classList.add("animate");
      },
      false
    );
  }
}

$(document.body).on("change", "form input.input-material", function (e) {
  //btn_salvar_aprovar
  //btn_recusar_cancelar
  $(".btn_salvar_aprovar")
    .html("salvar")
    .removeClass("btn-outline-primary")
    .addClass("btn-primary");
  $(".btn_recusar_cancelar").html("cancelar");
});

$(document.body).on(
  "click",
  "form .btn_salvar_aprovar, .btn_recusar_cancelar",
  function (e) {
    $(".btn_salvar_aprovar")
      .html(
        `aprovar
        <svg version="1.1" viewBox="0 0 406.834 406.834" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" width="12" class="pb-1">
          <polygon class="hoverWhite" fill="#007bff"
                  points="385.62 62.507 146.22 301.9 21.213 176.89 0 198.1 146.22 344.33 406.83 83.72" />
        </svg>`)
      .addClass("btn-outline-primary")
      .removeClass("btn-primary");

    $(".btn_recusar_cancelar").html(
      `recusar
      <svg version="1.1" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" width="12"class="pb-1">
        <path class="hoverWhite" fill="#007bff"  d="m28.941 31.786l-28.328 28.328c-0.787 0.787-0.787 2.062 0 2.849 0.393 0.394 0.909 0.59 1.424 0.59 0.516 0 1.031-0.196 1.424-0.59l28.541-28.541 28.541 28.541c0.394 0.394 0.909 0.59 1.424 0.59s1.031-0.196 1.424-0.59c0.787-0.787 0.787-2.062 0-2.849l-28.327-28.328 28.346-28.348c0.787-0.787 0.787-2.062 0-2.849-0.787-0.786-2.062-0.786-2.848 0l-28.559 28.561-28.562-28.56c-0.787-0.786-2.061-0.786-2.848 0-0.787 0.787-0.787 2.062 0 2.849l28.348 28.347z" />
      </svg>`
    );
  }
);

$(function () {
  jQuery(function ($) {
    $.datepicker.regional["pt-BR"] = {
      closeText: "Fechar",
      prevText: "&#x3c;Anterior",
      nextText: "Pr&oacute;ximo&#x3e;",
      currentText: "Hoje",
      monthNames: [
        "Janeiro",
        "Fevereiro",
        "Mar&ccedil;o",
        "Abril",
        "Maio",
        "Junho",
        "Julho",
        "Agosto",
        "Setembro",
        "Outubro",
        "Novembro",
        "Dezembro"
      ],
      monthNamesShort: [
        "Jan",
        "Fev",
        "Mar",
        "Abr",
        "Mai",
        "Jun",
        "Jul",
        "Ago",
        "Set",
        "Out",
        "Nov",
        "Dez"
      ],
      dayNames: [
        "Domingo",
        "Segunda-feira",
        "Ter&ccedil;a-feira",
        "Quarta-feira",
        "Quinta-feira",
        "Sexta-feira",
        "Sabado"
      ],
      dayNamesShort: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
      dayNamesMin: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
      weekHeader: "Sm",
      dateFormat: "dd/mm/yy",
      firstDay: 0,
      isRTL: false,
      showMonthAfterYear: false,
      yearSuffix: ""
    };
    $.datepicker.setDefaults($.datepicker.regional["pt-BR"]);
  });
  $(".input-material-date").datepicker();
});


(function ($) {

  // Check if Navigator is Internet Explorer
  if (navigator.userAgent.indexOf('MSIE') !== -1
    || navigator.appVersion.indexOf('Trident/') > -1) {

    // Scroll event check
    $(window).scroll(function (event) {
      var scroll = $(window).scrollTop();

      // Activate sticky for IE if scrolltop is more than 20px
      if (scroll > 20) {
        $('.sticky-top, .sticky-top-botoes').addClass("sticky-top-ie");
      } else {
        $('.sticky-top, .sticky-top-botoes').removeClass("sticky-top-ie");
      }

    });

  }

})(jQuery);


function loaderPage(timeoutSpn) {
  var htmlLoader = '<div class="modal-backdrop fade show" id="SPINNERPAGE"  style="opacity: 0.8;"><div style="display: flex; justify-content: center; align-items: center; height: 100vh" class="SPINNER-ICON"></div></div>';

  $(document.body).append(htmlLoader);

  setTimeout(() => {
    $('#SPINNERPAGE').remove()
  }, timeoutSpn);
}

//loaderPage(100);