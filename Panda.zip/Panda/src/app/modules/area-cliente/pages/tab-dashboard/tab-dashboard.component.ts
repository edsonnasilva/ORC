import { Component, OnInit } from "@angular/core";



const layoutGridStack = [
  {
    component: "pd-saldo-consolidado",
    w: "2",
    h: "4",
    x: "0",
    y: "0"
  },
  {
    component: "pd-atividades",
    w: "5",
    h: "4",
    x: "0"
  }
];

@Component({
  selector: "pd-tab-dashboard",
  templateUrl: "./tab-dashboard.component.html",
  styleUrls: ["./tab-dashboard.component.scss"]
})
export class TabDashboardComponent implements OnInit {
  layoutGridStack = layoutGridStack;

  constructor() {}

  ngOnInit() {

  }

}
