import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pd-tab-alocacao',
  templateUrl: './tab-alocacao.component.html',
  styleUrls: ['./tab-alocacao.component.scss']
})
export class TabAlocacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
